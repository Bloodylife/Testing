# RUET Student Portal — Firebase-free

A self-contained student portal using **Flask + SQLite**. No Firebase is used.

## Fixed student login mapping

- User ID = Roll number
- Initial password = Registration number
- Rolls: `2106001` → `2106060`
- Registration numbers: `845` → `904`

Example: `2106001 / 845`

Passwords are stored as secure hashes in the database, not plaintext.

## Run locally

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

Set a strong secret and admin password. The app also has development defaults so it runs immediately, but change them before deployment.

```bash
# Linux/macOS
export SECRET_KEY='a-long-random-secret'
export ADMIN_USERNAME='admin'
export ADMIN_PASSWORD='your-strong-admin-password'

python app.py
```

Open `http://127.0.0.1:5000`.

### Initial administrator login

Use the configured environment values. If none are provided, the development default is:

- Username: `admin`
- Password: `ChangeMeNow123!`

Change this before any real deployment.

## Included

- Student and administrator login
- 60 preloaded student accounts
- Secure password hashing
- Student dashboard
- Profile editing
- Password change
- Course listing
- Attendance/result-ready data model
- Admin student search/edit
- Admin notice publishing/deletion
- Admin course creation
- Health endpoint
- Responsive UI

## Production notes

For production, use a strong `SECRET_KEY`, HTTPS, a production WSGI server, backups, rate limiting, and a managed database if the user count grows. Do not use the development admin password.
