import os
import sqlite3
from functools import wraps
from pathlib import Path
from datetime import datetime

from flask import Flask, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "student_portal.db"

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-this-secret"),
    DATABASE=str(DB_PATH),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            roll TEXT NOT NULL UNIQUE,
            reg_no TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL DEFAULT '',
            email TEXT NOT NULL DEFAULT '',
            phone TEXT NOT NULL DEFAULT '',
            department TEXT NOT NULL DEFAULT 'Ceramic and Metallurgical Engineering',
            semester TEXT NOT NULL DEFAULT '4-1',
            section TEXT NOT NULL DEFAULT 'A',
            profile_photo TEXT NOT NULL DEFAULT '',
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS notices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            credit REAL NOT NULL DEFAULT 0,
            teacher TEXT NOT NULL DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            marks REAL NOT NULL DEFAULT 0,
            grade TEXT NOT NULL DEFAULT '',
            grade_point REAL NOT NULL DEFAULT 0,
            FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
            UNIQUE(student_id, course_id)
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            classes_held INTEGER NOT NULL DEFAULT 0,
            classes_present INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
            UNIQUE(student_id, course_id)
        );
        """
    )

    # Seed the fixed 60 accounts accurately. The initial password is the registration number.
    for i in range(60):
        roll = str(2106001 + i)
        reg_no = str(845 + i)
        existing = db.execute("SELECT id FROM students WHERE roll = ?", (roll,)).fetchone()
        if existing is None:
            db.execute(
                """
                INSERT INTO students (roll, reg_no, password_hash)
                VALUES (?, ?, ?)
                """,
                (roll, reg_no, generate_password_hash(reg_no)),
            )

    # Seed a few courses only when the database is empty.
    count = db.execute("SELECT COUNT(*) AS c FROM courses").fetchone()["c"]
    if count == 0:
        courses = [
            ("CME 4101", "Advanced Ceramic Processing", 3.0, "Course Teacher"),
            ("CME 4103", "Materials Characterization", 3.0, "Course Teacher"),
            ("CME 4105", "Materials for Energy Conversion and Storage", 3.0, "Course Teacher"),
            ("CME 4107", "Ceramic and Glass Technology", 3.0, "Course Teacher"),
            ("CME 4109", "Technical Elective", 3.0, "Course Teacher"),
        ]
        db.executemany(
            "INSERT INTO courses (code, title, credit, teacher) VALUES (?, ?, ?, ?)",
            courses,
        )

    db.commit()


def login_required(role=None):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                flash("You do not have permission to access that page.", "error")
                return redirect(url_for("index"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.context_processor
def inject_globals():
    return {"current_year": datetime.now().year}


@app.route("/")
def index():
    if session.get("role") == "student":
        return redirect(url_for("student_dashboard"))
    if session.get("role") == "admin":
        return redirect(url_for("admin_dashboard"))
    return render_template("landing.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user_id = request.form.get("user_id", "").strip()
        password = request.form.get("password", "")
        login_type = request.form.get("login_type", "student")
        db = get_db()

        if login_type == "admin":
            admin_user = os.environ.get("ADMIN_USERNAME", "admin")
            admin_password = os.environ.get("ADMIN_PASSWORD", "ChangeMeNow123!")
            if user_id == admin_user and password == admin_password:
                session.clear()
                session["role"] = "admin"
                session["user_id"] = admin_user
                return redirect(url_for("admin_dashboard"))
            flash("Invalid administrator credentials.", "error")
        else:
            student = db.execute("SELECT * FROM students WHERE roll = ?", (user_id,)).fetchone()
            if student and check_password_hash(student["password_hash"], password):
                session.clear()
                session["role"] = "student"
                session["user_id"] = student["id"]
                return redirect(url_for("student_dashboard"))
            flash("Invalid roll number or password.", "error")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/student/dashboard")
@login_required("student")
def student_dashboard():
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE id = ?", (session["user_id"],)).fetchone()
    notices = db.execute("SELECT * FROM notices ORDER BY datetime(created_at) DESC, id DESC LIMIT 5").fetchall()
    courses = db.execute(
        """
        SELECT c.*, a.classes_held, a.classes_present,
               CASE WHEN a.classes_held > 0 THEN ROUND((a.classes_present * 100.0) / a.classes_held, 1) ELSE NULL END AS attendance_pct,
               r.marks, r.grade, r.grade_point
        FROM courses c
        LEFT JOIN attendance a ON a.course_id = c.id AND a.student_id = ?
        LEFT JOIN results r ON r.course_id = c.id AND r.student_id = ?
        ORDER BY c.code
        """,
        (student["id"], student["id"]),
    ).fetchall()
    return render_template("student_dashboard.html", student=student, notices=notices, courses=courses)


@app.route("/student/profile", methods=["GET", "POST"])
@login_required("student")
def student_profile():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        department = request.form.get("department", "").strip()
        semester = request.form.get("semester", "").strip()
        section = request.form.get("section", "").strip()
        db.execute(
            """
            UPDATE students
            SET name=?, email=?, phone=?, department=?, semester=?, section=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
            """,
            (name, email, phone, department, semester, section, session["user_id"]),
        )
        db.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("student_profile"))
    student = db.execute("SELECT * FROM students WHERE id = ?", (session["user_id"],)).fetchone()
    return render_template("student_profile.html", student=student)


@app.route("/student/change-password", methods=["GET", "POST"])
@login_required("student")
def student_change_password():
    db = get_db()
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        student = db.execute("SELECT * FROM students WHERE id = ?", (session["user_id"],)).fetchone()
        if not check_password_hash(student["password_hash"], current):
            flash("Current password is incorrect.", "error")
        elif len(new_password) < 8:
            flash("New password must contain at least 8 characters.", "error")
        elif new_password != confirm:
            flash("New passwords do not match.", "error")
        else:
            db.execute(
                "UPDATE students SET password_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (generate_password_hash(new_password), session["user_id"]),
            )
            db.commit()
            flash("Password changed successfully.", "success")
            return redirect(url_for("student_dashboard"))
    return render_template("change_password.html")


@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    db = get_db()
    stats = {
        "students": db.execute("SELECT COUNT(*) AS c FROM students").fetchone()["c"],
        "courses": db.execute("SELECT COUNT(*) AS c FROM courses").fetchone()["c"],
        "notices": db.execute("SELECT COUNT(*) AS c FROM notices").fetchone()["c"],
    }
    students = db.execute("SELECT * FROM students ORDER BY roll LIMIT 10").fetchall()
    return render_template("admin_dashboard.html", stats=stats, students=students)


@app.route("/admin/students")
@login_required("admin")
def admin_students():
    q = request.args.get("q", "").strip()
    db = get_db()
    if q:
        students = db.execute(
            "SELECT * FROM students WHERE roll LIKE ? OR reg_no LIKE ? OR name LIKE ? ORDER BY roll",
            (f"%{q}%", f"%{q}%", f"%{q}%"),
        ).fetchall()
    else:
        students = db.execute("SELECT * FROM students ORDER BY roll").fetchall()
    return render_template("admin_students.html", students=students, q=q)


@app.route("/admin/student/<int:student_id>", methods=["GET", "POST"])
@login_required("admin")
def admin_student_edit(student_id):
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        department = request.form.get("department", "").strip()
        semester = request.form.get("semester", "").strip()
        section = request.form.get("section", "").strip()
        new_password = request.form.get("password", "")
        db.execute(
            """
            UPDATE students
            SET name=?, email=?, phone=?, department=?, semester=?, section=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
            """,
            (name, email, phone, department, semester, section, student_id),
        )
        if new_password:
            db.execute("UPDATE students SET password_hash=? WHERE id=?", (generate_password_hash(new_password), student_id))
        db.commit()
        flash("Student updated successfully.", "success")
        return redirect(url_for("admin_student_edit", student_id=student_id))
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if student is None:
        flash("Student not found.", "error")
        return redirect(url_for("admin_students"))
    return render_template("admin_student_edit.html", student=student)


@app.route("/admin/notices", methods=["GET", "POST"])
@login_required("admin")
def admin_notices():
    db = get_db()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        body = request.form.get("body", "").strip()
        if title and body:
            db.execute("INSERT INTO notices (title, body) VALUES (?, ?)", (title, body))
            db.commit()
            flash("Notice published.", "success")
        else:
            flash("Both title and message are required.", "error")
    notices = db.execute("SELECT * FROM notices ORDER BY datetime(created_at) DESC, id DESC").fetchall()
    return render_template("admin_notices.html", notices=notices)


@app.post("/admin/notices/<int:notice_id>/delete")
@login_required("admin")
def delete_notice(notice_id):
    db = get_db()
    db.execute("DELETE FROM notices WHERE id = ?", (notice_id,))
    db.commit()
    flash("Notice deleted.", "success")
    return redirect(url_for("admin_notices"))


@app.route("/admin/courses", methods=["GET", "POST"])
@login_required("admin")
def admin_courses():
    db = get_db()
    if request.method == "POST":
        code = request.form.get("code", "").strip()
        title = request.form.get("title", "").strip()
        credit = request.form.get("credit", "0").strip()
        teacher = request.form.get("teacher", "").strip()
        try:
            db.execute("INSERT INTO courses (code, title, credit, teacher) VALUES (?, ?, ?, ?)", (code, title, float(credit), teacher))
            db.commit()
            flash("Course added.", "success")
        except sqlite3.IntegrityError:
            flash("Course code already exists.", "error")
    courses = db.execute("SELECT * FROM courses ORDER BY code").fetchall()
    return render_template("admin_courses.html", courses=courses)


@app.get("/health")
def health():
    return {"status": "ok", "database": str(DB_PATH.name)}


def bootstrap():
    with app.app_context():
        init_db()


if __name__ == "__main__":
    bootstrap()
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=True)
